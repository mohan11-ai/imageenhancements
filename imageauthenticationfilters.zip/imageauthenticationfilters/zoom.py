import cv2 as cv


def zoom(img, zoom_factor=1.5):
    return cv.resize(img, None, fx=zoom_factor, fy=zoom_factor)


img = cv.imread('7.jpg')
# Original: 529 × 550


height, width = img.shape[:2]


zoomed = zoom(img, 1.5)
# Zoomed: 794 × 825 


cropped = zoomed[0:550, 0:529] # Wrong area
# Now I want to crop the middle of the new image as variable.


cv.imwrite('zoomed.png', zoomed)
cv.imwrite('cropped.png', cropped)

