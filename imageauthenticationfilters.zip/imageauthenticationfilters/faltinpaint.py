import cv2
img = cv2.imread('7.jpg')
mask = cv2.imread('mask.png',0)
res = cv2.bitwise_and(img,img,mask = mask)
cv2.imshow("Original Image", res)
cv2.waitKey(0)
cv2.destroyAllWindows()
