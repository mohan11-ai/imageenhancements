import cv2
import numpy as np
img = cv2.imread("7.jpg", 0)      # 1 chan, grayscale!
imf = np.float32(img)/255.0  # float conversion/scale
dst = cv2.dct(imf)           # the dct
img = np.uint8(dst)*255.0  
cv2.imshow("ela95", img)
#cv2.imshow("ela90", diff2)
cv2.waitKey(0)

