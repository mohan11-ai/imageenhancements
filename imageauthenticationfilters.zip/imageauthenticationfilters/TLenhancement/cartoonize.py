
def cartoon(img):
    import cv2
    import numpy as np
    #blur = cv2.GaussianBlur(img,(5,5),0)
    #print(gamaValue)
    for gamma in [3.6]:
    
	
	# Apply gamma correction
        img = np.array(255*(img / 255) ** gamma, dtype = 'uint8')
        
# denoising of image saving it into dst imag
       # dst = cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 15, 15)
        #img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        
        #(thresh, blackAndWhiteImage) = cv2.threshold(img, 69, 255, cv2.THRESH_BINARY)
         #img = cv2.Canny(img,200,300)    
   
    return img
  
def zoom(img):
    import cv2


def zoom(img, zoom_factor=1.5):
    return cv2.resize(img, None, fx=zoom_factor, fy=zoom_factor)


#img = cv.imread('7.jpg')
# Original: 529 × 550


    height, width = img.shape[:2]


    zoomed = zoom(img, 1.5)
# Zoomed: 794 × 825 


    img = zoomed[0:550, 0:529] # Wrong area
# Now I want to crop the middle of the new image as variable.

    return img

def elafilter(img):
    import cv2
    import numpy as np
    img1 = cv2.imread("7.jpg")

# set compression and scale
    jpg_quality1 = 95
    jpg_quality2 = 90
    scale = 15

# write img1 at 95% jpg compression
    cv2.imwrite("lenna_c95.jpg", img1, [cv2.IMWRITE_JPEG_QUALITY, jpg_quality1])

# read compressed image
    img2 = cv2.imread("lenna_c95.jpg")

# get absolute difference between img1 and img2 and multiply by scale
    diff1 = scale * cv2.absdiff(img1, img2)

# write img2 at 90% jpg compression
    cv2.imwrite("lenna_c90.jpg", img2, [cv2.IMWRITE_JPEG_QUALITY, jpg_quality2])

# read compressed image
    img3 = cv2.imread("lenna_c90.jpg")

# get absolute difference between img1 and img2 and multiply by scale
    img = scale * cv2.absdiff(img2, img3)

# write result to disk
    cv2.imwrite("lenna_ela_95.jpg", diff1)
    cv2.imwrite("lenna_ela_90.jpg", img)
    return img

def faltinpaint(img):

    import numpy as np
    import cv2

# Open the image.
    #img = cv2.imread('7.jpg')

# Load the mask.
    mask= cv2.imread('cat_mask.png', 0)

# Inpaint.
    img = cv2.inpaint(img, mask, 3, cv2.INPAINT_NS)
    
    return img
    
    
    
def gradient(img):

    import numpy as np
    import cv2
    from matplotlib import pyplot as plt
    #img = cv.imread('dave.jpg',0)
    img = cv2.Laplacian(img,cv2.CV_64F)
    sobelx = cv2.Sobel(img,cv2.CV_64F,1,0,ksize=5)
    sobely = cv2.Sobel(img,cv2.CV_64F,0,1,ksize=5)
    kernelx = np.array([[1,1,1],[0,0,0],[-1,-1,-1]])
    kernely = np.array([[-1,0,1],[-1,0,1],[-1,0,1]])
    img_prewittx = cv2.filter2D(img, -1, kernelx)
    img_prewitty = cv2.filter2D(img, -1, kernely)
    
    
    
    return img
    
def cloning(img):   
# Standard imports
    import cv2
    import numpy as np 

# Read images
    img= cv2.imread("images/airplane.jpg")
    img1 = cv2.imread("images/sky.jpg")

# Create a rough mask around the airplane.
    src_mask = np.zeros(src.shape, src.dtype)
    poly = np.array([ [4,80], [30,54], [151,63], [254,37], [298,90], [272,134], [43,122] ], np.int32)
    cv2.fillPoly(src_mask, [poly], (255, 255, 255))

# This is where the CENTER of the airplane will be placed
    center = (800,100)

# Clone seamlessly.
    img = cv2.seamlessClone(img, img1, src_mask, center, cv2.NORMAL_CLONE)
    
    return img

def masking(img):
    import cv2 # Import the OpenCV library
    import numpy as np # Import Numpy library
    #img = cv2.imread('forged1.png')
    img1 = cv2.imread('mask.png',0)
    img= cv2.bitwise_and(img,img1,mask = mask)
    
    return img
    

import cv2
import matplotlib.pyplot as plt
def splicing(img):
  #img=cv2.imread('7.jpg')

  img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
  k = cv2.getStructuringElement(cv2.MORPH_RECT,(5, 5))   
    
  #erosion = cv2.erode(img, k, iterations = 1)
    
  #dilation = cv2.dilate(img, k, iterations = 1)
        
  img = cv2.morphologyEx(img, cv2.MORPH_GRADIENT, k)
  
  #dilatedg= cv2.dilate(gradientImg, k, iterations = 1)
  #output = [img, erosion, dilation, gradientImg]

  return img
