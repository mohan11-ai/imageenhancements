import cv2 # Import the OpenCV library
import numpy as np # Import Numpy library
img = cv2.imread('forged1.png')
mask = cv2.imread('mask.png',0)
res = cv2.bitwise_and(img,img,mask = mask)
 
    # Display images, used for debugging
    #cv2.imshow('Original Image', image)
    #cv2.imshow('Sketched Mask', image_mark)
    #cv2.imshow('Mask', mask)
    #cv2.imshow('Output Image', output)
cv2.imshow('Table of Images', res)
cv2.waitKey(0) # Wait for a keyboard event
 

