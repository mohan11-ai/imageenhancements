
    
    
    #a = np.double(img)
    #b = a + 15
    #img = np.uint8(b)
    #img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    #(thresh,img) = cv2.threshold(img, 59, 255, cv2.THRESH_BINARY)

def cartoon(img,gamaValue):
    import cv2
    import numpy as np
    #blur = cv2.GaussianBlur(img,(5,5),0)
    #print(gamaValue)
    for gamma in [gamaValue]:
    
	
	# Apply gamma correction.
        img = np.array(255*(img / 255) ** gamma, dtype = 'uint8')
        
# denoising of image saving it into dst imag
       # dst = cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 15, 15)
        #img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        
        #(thresh, blackAndWhiteImage) = cv2.threshold(img, 69, 255, cv2.THRESH_BINARY)
         #img = cv2.Canny(img,200,300)    
   
    return img
  
    
def hist(img):
    import cv2
    import numpy as np
   
        
    img_grey = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    #contrast = img_grey.std()
    img = cv2.equalizeHist(img_grey)
    #(thresh, img) = cv2.threshold(img, 5, 255, cv2.THRESH_BINARY)
    return img

def blurring(img):
    import cv2
    import numpy as np


    img = cv2.resize(img, (0, 0), None, .25, .25)

    gaussianBlurKernel = np.array(([[1, 2, 1], [2, 4, 2], [1, 2, 1]]), np.float32)/9
    sharpenKernel = np.array(([[0, -1, 0], [-1, 9, -1], [0, -1, 0]]), np.float32)/9
    meanBlurKernel = np.ones((3, 3), np.float32)/9

    gaussianBlur = cv2.filter2D(src=img, kernel=gaussianBlurKernel, ddepth=-1)
    meanBlur = cv2.filter2D(src=img, kernel=meanBlurKernel, ddepth=-1)
    sharpen = cv2.filter2D(src=img, kernel=sharpenKernel, ddepth=-1)

    img= np.concatenate((img, gaussianBlur, meanBlur, sharpen), axis=1)
    
    return img
    
def sharpening(img):
    import cv2
    import numpy as np   
    kernel3 = np.array([[0, -1,  0],
	            [-1,  5, -1],

	            [0, -1,  0]])

    img = cv2.filter2D(src=img, ddepth=-1, kernel=kernel3)
    
    return img
    
def bilateral(img):

    import cv2  
    import numpy as np  

  

    img = cv2.bilateralFilter(img,9,50,50)
    return img 
    
    
def blackwhite(img):

    import cv2
  

    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
  
    (thresh, img) = cv2.threshold(img, 69, 255, cv2.THRESH_BINARY)
    
    return img
    
    
def bright(img, value=70):
    import cv2
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    v = cv2.add(v,value)
    v[v > 255] = 255
    v[v < 0] = 0
    final_hsv = cv2.merge((h, s, v))
    img = cv2.cvtColor(final_hsv, cv2.COLOR_HSV2BGR)
    return img
    
    
def RGBcolour(img):


    import cv2
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    
    return img
def HSVcolour(img):


    import cv2
    img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    
    
    return img    
    
def HLScolour(img):


    import cv2
    img = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)

    
    
    return img
    
    
def negative(img):
    import numpy as np
   
    img = np.invert(img)
    
    return img
    
    
def denoise(img):

    import cv2
  
# denoising of image saving it into dst image
    img = cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 15)
    
    return img
    
    
    
def morph(img):

    # Python program to demonstrate erosion and
# dilation of images.
    import cv2
    import numpy as np


# Taking a matrix of size 5 as the kernel
    kernel = np.ones((5,5), np.uint8)

# The first parameter is the original image,
# kernel is the matrix with which image is
# convolved and third parameter is the number
# of iterations, which will determine how much
# you want to erode/dilate a given image.
    img = cv2.erode(img, kernel, iterations=1)
    img = cv2.dilate(img, kernel, iterations=1)
    return img
    
    


    
    

 

   





