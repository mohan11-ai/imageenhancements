# install opencv-python-headless==4.4.0.42 for opencv in heroku
from main import app 
  
if __name__ == "__main__": 
        app.run() 